<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
  <title><?php if(!empty($title)){ echo $title; }else{ echo 'index'; } ?></title>
  <?php   $logo=  $this->db->get_where('site_options',array('option_name'=>'site_logo'))->row()->option_value; 
        if(!empty($logo))
        {
        $img =   base_url().$logo; 
        }
        else
        {
        $img=  base_url().'assets/front/images/logo.png';
        } ?>
  <link rel="apple-touch-icon" href="<?php echo $img; ?>">
 <!-- <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/admin/app-assets/images/ico/favicon.png">-->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Quicksand:300,400,500,700"
  rel="stylesheet">
 <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome.min.css"
  rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/vendors.min.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/tables/datatable/datatables.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/weather-icons/climacons.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/fonts/meteocons/style.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/charts/morris.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/charts/chartist.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/charts/chartist-plugin-tooltip.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/forms/icheck/icheck.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/forms/icheck/custom.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/app.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/core/menu/menu-types/vertical-menu-modern.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/core/colors/palette-gradient.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/fonts/simple-line-icons/style.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/forms/toggle/bootstrap-switch.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/core/colors/palette-gradient.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/pages/timeline.min.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/ui/jquery-ui.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/pages/dashboard-ecommerce.min.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/plugins/forms/checkboxes-radios.min.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/core/colors/palette-switch.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/app-assets/css/font-awesome.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/app-assets/css/richtext.min.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/ui/dragula.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/app-assets/css/ssi-uploader.css"/>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/slideshow.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/plugins/ui/jqueryui.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/assets/css/style.css">

  <!--link href="<?php echo base_url(); ?>assets/front/css/validin.css" rel="stylesheet"-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/employer/css/chosen.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/vendors/css/forms/selects/selectivity-full.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/plugins/forms/selectivity/selectivity.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin/app-assets/css/pages/email-application.css">


  
  
  </head>
  <style>
      .badge, .badge[class*=badge-] a {
    color: white;
    background-color: dodgerblue;
    border-radius: 61% 46% 61% 49%;
        display: inline-block;
    padding: 0.35em .4em;
    font-size: 42%;
    text-align: center;
    vertical-align: baseline;
}



.dropdownt {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 256px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdownt:hover .dropdown-content {display: block;}

.alert-danger, .alert-success {  position: fixed;
        max-width: 50%;
        width: 100%;
        top: 15%;
        left: 0;
        right:0;
        margin: auto;
        z-index: 111111;
        box-shadow: 1px 1px 8px rgba(0, 0, 0, 0.15);
        text-align: center;
      }
.alert.alert-danger{
    left: 0;
    right:0;
}


  </style>
<body class="vertical-layout vertical-menu-modern 2-columns <?php if($this->uri->segment(2)=="message" || $this->uri->segment(2)=="compose" || $this->uri->segment(2)=="inbox" || $this->uri->segment(2)=="sent" || $this->uri->segment(2)=="draft" || $this->uri->segment(2)=="trash" || $this->uri->segment(2)=="starred" || $this->uri->segment(2)=="group" || $this->uri->segment(2)=="viewmail"){ echo "email-application"; }?> menu-expanded fixed-navbar"
data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">
  <!-- fixed-top-->
  <nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-dark navbar-shadow">
    <div class="navbar-wrapper">
      <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
          <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
          <li class="nav-item mr-auto">
            <a class="navbar-brand" href="<?php echo base_url().'admin/dashboard';?>">
                <?php $img = $this->db->get_where('site_options',array('option_name'=>'site_logo'))->row()->option_value; 
                if(empty($img))
                {
                ?>
              <img class="brand-logo logo-1" alt="" src="<?php echo base_url(); ?>assets/admin/app-assets/images/logo/logo.png" >
              <?php }else
              {?>
              <img class="brand-logo logo-1" alt="" src="<?php echo base_url(); ?><?= $img; ?>">
              <?php } ?>
            </a>
          </li>
          <li class="nav-item d-none d-md-block float-right"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="toggle-icon ft-toggle-right font-medium-3 white" data-ticon="ft-toggle-right"></i></a></li>
          <li class="nav-item d-md-none">
            <a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a>
          </li>
        </ul>
      </div>
      <div class="navbar-container content">
        <div class="collapse navbar-collapse" id="navbar-mobile">
          <ul class="nav navbar-nav mr-auto float-left">
            <li class="nav-item d-none d-md-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>
		 </ul>
          <ul class="nav navbar-nav float-right">
               <?php 
                   if($this->session->userdata('userId')!='')
                   {
                	  $usernotyfi = $this->Common->getData('notifications',array('to_id'=>$this->session->userdata('userId'),'to_for'=>'Admin','status'=>'1'),array('notify_id'=>'desc'),5);
                      $usernotyficount = $this->Common->getData('notifications',array('to_id'=>$this->session->userdata('userId'),'to_for'=>'Admin','status'=>'1'));
                       
                   }
                
                if(empty($usernotyfi)){ ?>
                <li class="dropdown dropdown-user nav-item">
                  <a class="dropdown-toggle nav-link dropdown-user-link" href="<?php echo base_url();?>admin/employer/notificationall" data-toggle="dropdown">
                  <span class="user-name text-bold-700"><i class="fa fa-bell" style="font-size:29px;color:black" aria-hidden="true"></i></span>
                  </a>
                  </li>
                <? }else { ?>
              <li class="dropdown dropdown-user nav-item dropdownt">
                  <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
               
                  <span class="user-name text-bold-700"><i class="fa fa-bell" style="font-size:29px;color:red" aria-hidden="true"><span class="badge"><?php echo count($usernotyficount); ?></span></i></span>
                        <div class="dropdown-content bg-white">
                            <?php foreach($usernotyfi as $noty) { 
                                
                            
                                $datetime= $noty->created_at;
    $full='';
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }
    if($noty->from_for == 'Employe'){
    $employerpic= $this->db->get_where('employers',array('id'=>$noty->from_id))->row()->profile_photo;
    
    	if(!empty($employerpic)){
        $imagep = base_url("assets/employer/images/".$employerpic);
        }else{
        $imagep = base_url('assets/employer/images/default.jpeg');
        } 
    }
   
    if($noty->from_for == 'User'){
     $employerpics= $this->db->get_where('candidates',array('id'=>$noty->from_id))->row()->profile_pic;

	if(!empty($employerpics)){
    $imagep = base_url($employerpics);
    }else{
    $imagep = base_url('assets/employer/images/default.jpeg');
              

    } 
    }
                            ?>
        <a href="javascript:void(0);" tbl="<?php echo $noty->about; ?>" about-id="<?php echo $noty->about_id; ?>" class="notification_see" notify-id="<?php echo $noty->notify_id; ?>" data-baseurl="<?php echo base_url(); ?>admin/employer/edit-posted-jobs?id=<?php echo $noty->about_id; ?>"  action="<?php echo base_url();?>admin/employer/notificationstatusupdates" >
        <img src="<?= $imagep; ?>" class="noti-img"  alt="avatar"> <?php echo $noty->message; ?> <label class="notify-time"> <?php  if (!$full) $string = array_slice($string, 0, 1);
    echo  $string ? implode(', ', $string) . ' ago' : 'just now'; ?></label></span></a>
                        <?php  } ?>
                        <a href="<?php echo base_url();?>admin/employer/notificationall" style="text-align:center;padding: 10px;"><span>See All > </span></a>
                      </div>
                  </a>
                  </li>
                  <? } ?>
            <li class="dropdown dropdown-user nav-item">
                 <?php 
                   if($this->session->userdata('userId')!='')
                   {
                	$userdetail = $this->Common->getData('tbl_admin',array('id'=>$this->session->userdata('userId')),"","",1);
                   }
                
                if($userdetail==''){ ?>
              <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
               
                  <span class="user-name text-bold-700">John Doe</span>
               
                <span class="avatar avatar-online">
                  <img src="<?php echo base_url(); ?>assets/admin/app-assets/images/portrait/small/avatar-s-19.png" alt="avatar"><i></i></span>
              </a>
              <?php }else{ ?>
              
               <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
               
                  <span class="user-name text-bold-700"><?php echo Ucfirst($userdetail->first_name.' '.$userdetail->last_name); ?></span>
               
                <span class="avatar avatar-online">
                    <?php if(!empty($userdetail->avatar))
                    {
                        $img= $userdetail->avatar;
                    }else
                    {
                       $img= 'assets/admin/app-assets/images/portrait/small/avatar-s-19.png';
                    } ?>
                  <img src="<?php echo base_url(); ?>/<?php echo $img; ?>" alt="avatar"><i></i></span>
              </a>
              <?php } ?>
              <div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item" href="<?php echo base_url(); ?>admin/my-account"><i class="ft-user"></i>My Account</a>
				<div class="dropdown-divider"></div><a class="dropdown-item" href="<?php echo base_url(); ?>admin/logout"><i class="ft-power"></i> Logout</a>
              </div>
            </li>
         </ul>
        </div>
      </div>
    </div>
  </nav>
  <!-- ////////////////////////////////////////////////////////////////////////////-->
  <div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
      <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
        
		<li class="<?php if($this->uri->segment(2)=="dashboard"){echo "active";}?>  nav-item"><a href="<?php echo base_url(); ?>admin/dashboard"><i class="la la-home"></i><span class="menu-title">Dashboard</span></a>
        </li>
        <li class="<?php if($this->uri->segment(2)=="site-setting"){echo "active";}?> nav-item"><a href="<?php echo base_url(); ?>admin/site-setting"><i class="fa fa-cog"></i><span class="menu-title">Site Setting</span></a>
        </li>
        <li class="<?php if($this->uri->segment(3)=="industry-type"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/job/industry-type"><i class="fa fa-industry"></i><span class="menu-title">Industry Type</span></a>
		</li>
		<li class="<?php if($this->uri->segment(3)=="Category-type"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/job/Category-type"><i class="la la-list"></i><span class="menu-title">Job Category</span></a>
		</li>
		<li class="<?php if($this->uri->segment(3)=="Qualification-type"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/job/Qualification-type"><i class="fa fa-graduation-cap"></i><span class="menu-title">Job Qualification</span></a>
		</li>
		<li class="<?php if($this->uri->segment(3)=="job_location"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/job/job_location"><i class="la la-map-marker"></i><span class="menu-title">Job Location</span></a>
		</li>
		<li class="<?php if($this->uri->segment(2)=="skills"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/skills"><i class="fa fa-cogs"></i><span class="menu-title">Skills</span></a>
		</li>
		
		<li class=" nav-item">
			<a href="javascript:void(0)">
				<i class="la la-file-text-o"></i>
				<span class="menu-title">CMS</span>
			</a>
			<ul class="menu-content">
			    <li class="<?php if($this->uri->segment(2)=="contact-us"){echo "active";}?>  nav-item"><a class="menu-item" href="<?php echo base_url(); ?>admin/contact-us">Contact Us</a></li>
				<!--li><a class="menu-item" href="auto-mail.php">Email Contents</a></li-->
				<li class="<?php if($this->uri->segment(2)=="content-pages"){echo "active";}?>  nav-item"><a class="menu-item" href="<?php echo base_url(); ?>admin/content-pages">Content Pages</a></li>
				<!--li><a class="menu-item" href="<?php echo base_url(); ?>admin/content-upload-page">CMS Upload Page</a></li-->
				<li class="<?php if($this->uri->segment(2)=="faq"){echo "active";}?>  nav-item"><a class="menu-item" href="<?php echo base_url(); ?>admin/faq">FAQ</a></li>
				<!--li><a class="menu-item" href="manage-front-menu.php">Manage Frontend Menu</a></li>
				<li><a class="menu-item" href="menu-permission.php">Menu Permission</a></li>
				<li><a class="menu-item" href="manage-ad-banner.php">Manage Ad Banner</a></li-->
			</ul>
        </li>
        
        <li class="<?php if($this->uri->segment(3)=="seeker-profile"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/candidate/seeker-profile"><i class="la la-user"></i><span class="menu-title">Seeker's Profile</span></a>
        </li>
        
        <li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-briefcase"></i><span class="menu-title">Manage Employers</span></a>
			  <ul class="menu-content">
				<li class="<?php if($this->uri->segment(3)=="index"){echo "active";}?> nav-item">
				    <a class="menu-item" href="<?php echo base_url(); ?>admin/employer/index">Employer's Profile</a>
				</li>
				<li class="<?php if($this->uri->segment(3)=="employers-posted-jobs"){echo "active";}?> nav-item">
				    <a class="menu-item" href="<?php echo base_url(); ?>admin/employer/employers-posted-jobs">Employer's Posted jobs</a>
				</li>
				<!--li><a class="menu-item" href="unregistered-jobs.php">Unregistered company post job</a>
				</li>
				<li><a class="menu-item" href="send-job-request.php">Send Job Request</a>
				</li-->
				
			  </ul>
        </li>
        
        <li  class="<?php if($this->uri->segment(2)=="newsletters"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/newsletters"><i class="la la-paper-plane"></i><span class="menu-title">Newsletters</span></a>
        </li>
        <li  class="<?php if($this->uri->segment(2)=="message"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/message"><i class="la la-envelope"></i><span class="menu-title">Messages</span></a>
        </li>
        <li  class="<?php if($this->uri->segment(2)=="message"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/template"><i class="la la-envelope"></i><span class="menu-title">Email Templates</span></a>
        </li>
        
        <li class="<?php if($this->uri->segment(2)=="job-postings"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/job-postings"><i class="la la-dollar"></i><span class="menu-title">Subscription Settings</span></a>
        </li>
        <li class="<?php if($this->uri->segment(2)=="transaction"){echo "active";}?> nav-item">
			<a href="<?php echo base_url(); ?>admin/transaction"><i class="la la-money"></i><span class="menu-title">Transactions</span></a>
        </li>
		
		<!--li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-cog"></i><span class="menu-title">General</span></a>
			  <ul class="menu-content">
				<li><a class="menu-item" href="site-setting">Site Settings</a></li>
				<li><a class="menu-item" href="listing-count-editors">Listing count </a></li>
				<!--li><a class="menu-item" href="business-category.php">Business Category</a></li>
				<li><a class="menu-item" href="event-gallery.php">Event Gallery</a></li>
				<li><a class="menu-item" href="event-gallery-category.php">Event Gallery Category</a></li-->
			  <!--/ul>
        </li>
		
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-user"></i><span class="menu-title">User</span></a>
			<ul class="menu-content">
			<li>
				<a class="menu-item" href="administrator-members.php">Administrator</a>
			</li>
			<li>
				<a class="menu-item" href="subadministrator-members.php">Sub Administrator</a>
			</li>
			</ul>
        </li>
		
		<li class=" nav-item">
			<a href="categories-functional-area.php"><i class="la la-list"></i><span class="menu-title">Functional Area</span></a>
		</li>
	
		<li class=" nav-item">
			<a href="countrylist.php"><i class="la la-map-marker"></i><span class="menu-title">Location Management</span></a>
		</li>
		
		<li class=" nav-item">
			<a href="education_details.php"><i class="la la-graduation-cap"></i><span class="menu-title">Education Details</span></a>
		</li>
		<li class=" nav-item">
			<a href="platforms.php"><i class="la la-leaf"></i><span class="menu-title">Platforms</span></a>
		</li>
	
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-user"></i><span class="menu-title">Manage Seekers</span></a>
			  <ul class="menu-content">
				<li><a class="menu-item" href="seeker-profile.php">Seeker's Profile</a>
				</li>
				<li><a class="menu-item" href="import-data.php">Import Data's</a>
				</li>
				<li><a class="menu-item" href="resume-access.php">Resume Access</a>
				</li>
				<li><a class="menu-item" href="inactive-resume-users.php">Inactive Resume Users</a>
				</li>
				
			  </ul>
        </li>
		
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-briefcase"></i><span class="menu-title">Manage Employers</span></a>
			  <ul class="menu-content">
				<li><a class="menu-item" href="employers-profile.php">Employer's Profile</a>
				</li>
				<li><a class="menu-item" href="employers-posted-jobs.php">Employer Posted jobs</a>
				</li>
				<li><a class="menu-item" href="unregistered-jobs.php">Unregistered company post job</a>
				</li>
				<li><a class="menu-item" href="send-job-request.php">Send Job Request</a>
				</li>
				
			  </ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-paper-plane"></i><span class="menu-title">Newsletters</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="employers-profile.php">Job seekers</a></li>
				<li><a class="menu-item" href="recruiters-profile.php"> Recruiters</a></li>
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-dollar"></i><span class="menu-title">Price Settings</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="database-access.php">Database Access Price</a></li>
				<li><a class="menu-item" href="job-postings.php">Job Postings </a></li>
				<li><a class="menu-item" href="seeker-plan.php">Job Seekers Plan</a></li>
				<li><a class="menu-item" href="traininginstitute-plan.php">Traing Institute Plan</a></li>
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-users"></i><span class="menu-title">Employers Order</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="employers-database-access.php">Database Access</a></li>
				<li><a class="menu-item" href="job-posting-access.php"> Job Postings Access </a></li>
			</ul>
        </li>
		
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-user"></i><span class="menu-title">Seeker Membership</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="membership-request.php">Membership Request</a></li>
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-file"></i><span class="menu-title">Placement Papers</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="manage-company.php">Manage Company List</a></li>
				<li><a class="menu-item" href="manage-category.php">Manage Categories List</a></li>
				<li><a class="menu-item" href="manage-placement-papers.php">Manage Placement Papers</a></li>
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-file"></i><span class="menu-title">Experts Advice</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="manage-advice.php">Manage Advice</a></li>
				
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-cogs"></i><span class="menu-title">Employers Access</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="employee-database-access.php">Database Access</a></li>
				<li><a class="menu-item" href="employer-job-posting-access.php">Job Postings Access</a></li>
				
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-file-text-o"></i><span class="menu-title">Online Test / Training</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="test-categories.php">Test Categories</a></li>
				<li><a class="menu-item" href="test-users.php">Test Users</a></li>
				<li><a class="menu-item" href="training-categories.php">Training Categories</a></li>
				
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-file"></i><span class="menu-title">Placement / Training </span></a>
			<ul class="menu-content">
			<li><a class="menu-item" href="traininginstitute.php">Institute</a></li>
			<li><a class="menu-item" href="trainingconsultancy.php">Consultancy</a></li>
			</ul>
		</li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-users"></i><span class="menu-title">Groups</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="manage-groups.php">Groups Manage</a></li>
				
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-files-o"></i><span class="menu-title">Ads Management</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="ads.php">Ads</a></li>
				
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-bar-chart"></i><span class="menu-title">Reports</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="cv-search-industry.php">CV's Search-Industry</a></li>
				<li><a class="menu-item" href="cv-search-industry.php">CV's Search-Functional area</a></li>
				<li><a class="menu-item" href="reports.php">Reports</a></li>
			</ul>
        </li>
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-language"></i><span class="menu-title">Language Management</span></a>
			<ul class="menu-content">
				<li><a class="menu-item" href="language-list.php">Language Management</a></li>
				<li><a class="menu-item" href="page-list.php">Page Management</a></li>
				<li><a class="menu-item" href="words-management.php">Words Management</a></li>
			</ul>
        </li-->
		<!--li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-building-o"></i><span class="menu-title">Industry N'Site</span></a>
			  <ul class="menu-content">
				<li><a class="menu-item" href="category.php">Category</a>
				</li>
				<li><a class="menu-item" href="article.php">Article</a>
				</li>
			  </ul>
        </li>
		
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-file-code-o"></i><span class="menu-title">Document Management</span></a>
			  <ul class="menu-content">
				<li><a class="menu-item" href="manage-category.php">Manage Category</a>
				</li>
				<li><a class="menu-item" href="manage-document.php">Manage Document</a>
				</li>
			  </ul>
        </li>
		
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-paste"></i><span class="menu-title">Class</span></a>
			  <ul class="menu-content">
				<li><a class="menu-item" href="manage-class.php">Manage Class</a>
				</li>
				<li><a class="menu-item" href="manage-class-payment.php">Manage Class Payment</a>
				</li>
			  </ul>
        </li>
		
		<li class=" nav-item">
			<a href="javascript:void(0)"><i class="la la-building-o"></i><span class="menu-title">Property</span></a>
			  <ul class="menu-content">
				<li><a class="menu-item" href="manage-property.php">Manage Property</a>
				</li>
				
			  </ul>
        </li>
		
		<li class=" nav-item"><a href="newsletter.php"><i class="la la-newspaper-o"></i><span class="menu-title">Newsletter</span></a>
        </li>
		<li class=" nav-item"><a href="preferred-client-code.php"><i class="la la-code-fork"></i><span class="menu-title">Preferred Client Code</span></a>
        </li-->
      </ul>
    </div>
  </div>
  